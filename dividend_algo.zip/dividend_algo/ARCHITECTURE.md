# System Architecture - Dividend Capture Algorithm

## 📊 High-Level Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER INTERFACE                           │
│                          (main.py)                               │
│  ┌──────────────┬──────────────┬──────────────┬──────────────┐ │
│  │  Full Period │  Train/Test  │ Walk-Forward │   Parameter  │ │
│  │   Backtest   │    Split     │   Analysis   │    Sweep     │ │
│  └──────────────┴──────────────┴──────────────┴──────────────┘ │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    BACKTESTING ENGINE                            │
│                      (backtester.py)                             │
│                                                                  │
│  • Simulation loop (daily)                                      │
│  • Transaction cost modeling                                    │
│  • Position tracking                                            │
│  • Equity curve generation                                      │
│  • Performance calculation                                      │
└───────┬──────────────┬──────────────┬──────────────┬───────────┘
        │              │              │              │
        ▼              ▼              ▼              ▼
┌──────────────┐ ┌──────────┐ ┌──────────────┐ ┌──────────────┐
│     DATA     │ │ STRATEGY │ │     RISK     │ │  ANALYTICS   │
│   MANAGER    │ │          │ │   MANAGER    │ │              │
│  (data_mgr)  │ │(strategy)│ │ (risk_mgr)   │ │ (analytics)  │
└──────────────┘ └──────────┘ └──────────────┘ └──────────────┘
```

## 🔄 Detailed Component Flow

### 1. Data Pipeline

```
┌─────────────────────────────────────────────────────────────┐
│                     DATA MANAGER                             │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────────┐         ┌──────────────────┐         │
│  │  Alpaca API      │         │   yfinance       │         │
│  ├──────────────────┤         ├──────────────────┤         │
│  │ • Price bars     │         │ • Dividends      │         │
│  │ • OHLCV data     │         │ • Ex-dates       │         │
│  │ • Real-time      │         │ • Fundamentals   │         │
│  │ • Volume         │         │ • Quality data   │         │
│  └────────┬─────────┘         └────────┬─────────┘         │
│           │                            │                    │
│           └──────────┬─────────────────┘                    │
│                      ▼                                       │
│         ┌─────────────────────────┐                         │
│         │   Unified Data Store    │                         │
│         ├─────────────────────────┤                         │
│         │ • Dividend calendar     │                         │
│         │ • Price history         │                         │
│         │ • Fundamental metrics   │                         │
│         │ • Technical indicators  │                         │
│         └────────────┬────────────┘                         │
│                      │                                       │
└──────────────────────┼───────────────────────────────────────┘
                       │
                       ▼
                 [SCREENING]
```

### 2. Signal Generation

```
┌─────────────────────────────────────────────────────────────┐
│                    STRATEGY MODULE                           │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  SCREENING (stock universe)                                 │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ ✓ Dividend yield (2-8%)                              │  │
│  │ ✓ Market cap (>$1B)                                  │  │
│  │ ✓ Volume (>500K/day)                                 │  │
│  │ ✓ Quality score (>70/100)                            │  │
│  │ ✓ Financial health (debt, ROE, P/E)                  │  │
│  └───────────────────────┬──────────────────────────────┘  │
│                          │                                   │
│                          ▼                                   │
│  ENTRY SIGNALS                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ • Days to ex-dividend: 3-5                           │  │
│  │ • Technical filters:                                 │  │
│  │   - RSI (30-70)                                      │  │
│  │   - Z-score (-2 to 0)                                │  │
│  │   - Momentum (positive)                              │  │
│  │   - Volatility (<30%)                                │  │
│  │ • Mean reversion setup                               │  │
│  └───────────────────────┬──────────────────────────────┘  │
│                          │                                   │
│                          ▼                                   │
│  POSITION TRACKING                                          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ • Monitor all open positions                         │  │
│  │ • Calculate P&L                                      │  │
│  │ • Track days held                                    │  │
│  │ • Update stop losses                                 │  │
│  └───────────────────────┬──────────────────────────────┘  │
│                          │                                   │
│                          ▼                                   │
│  EXIT SIGNALS                                               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ • Stop loss (-2% or 1x dividend)                     │  │
│  │ • Profit target (1.5x div yield or 3%)               │  │
│  │ • Time stop (10 days max)                            │  │
│  │ • Mean reversion complete                            │  │
│  │ • Trailing stop (after +1.5%)                        │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### 3. Risk Management

```
┌─────────────────────────────────────────────────────────────┐
│                    RISK MANAGER                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  POSITION SIZING                                            │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Kelly Criterion:                                     │  │
│  │  f* = (p×b - q) / b × 0.25                          │  │
│  │                                                       │  │
│  │  Max: 2% per position                                │  │
│  │  Consider: Available cash, risk limits               │  │
│  └───────────────────────┬──────────────────────────────┘  │
│                          │                                   │
│                          ▼                                   │
│  PORTFOLIO CONSTRAINTS                                      │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ ✓ Max 25 positions                                   │  │
│  │ ✓ Sector limit: 30%                                  │  │
│  │ ✓ Cash reserve: 20%                                  │  │
│  │ ✓ Beta range: 0.5-0.8                                │  │
│  │ ✓ Correlation: <0.6                                  │  │
│  └───────────────────────┬──────────────────────────────┘  │
│                          │                                   │
│                          ▼                                   │
│  CIRCUIT BREAKERS                                           │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 🛑 Daily loss: -3%                                   │  │
│  │ 🛑 Monthly loss: -8%                                 │  │
│  │ 🛑 Max drawdown: -12%                                │  │
│  │ 🛑 VaR 95%: 2%                                       │  │
│  └───────────────────────┬──────────────────────────────┘  │
│                          │                                   │
│                          ▼                                   │
│  RISK MONITORING                                            │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ • Real-time portfolio value                          │  │
│  │ • Drawdown tracking                                  │  │
│  │ • VaR & CVaR calculation                             │  │
│  │ • Correlation monitoring                             │  │
│  │ • Beta calculation                                   │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### 4. Analytics & Reporting

```
┌─────────────────────────────────────────────────────────────┐
│                    ANALYTICS MODULE                          │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  PERFORMANCE METRICS                                        │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Returns:                                             │  │
│  │  • Total, Annual, Daily                              │  │
│  │                                                       │  │
│  │ Risk-Adjusted:                                       │  │
│  │  • Sharpe, Sortino, Calmar                           │  │
│  │                                                       │  │
│  │ Risk:                                                │  │
│  │  • Max DD, Volatility, VaR, CVaR                     │  │
│  │                                                       │  │
│  │ Trading:                                             │  │
│  │  • Win rate, Profit factor, Avg win/loss            │  │
│  └───────────────────────┬──────────────────────────────┘  │
│                          │                                   │
│                          ▼                                   │
│  VISUALIZATIONS                                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ 1. equity_curve.png                                  │  │
│  │    ├─ Portfolio value                                │  │
│  │    └─ # of positions                                 │  │
│  │                                                       │  │
│  │ 2. drawdown.png                                      │  │
│  │    └─ Underwater chart                               │  │
│  │                                                       │  │
│  │ 3. monthly_returns.png                               │  │
│  │    └─ Heatmap by year/month                          │  │
│  │                                                       │  │
│  │ 4. rolling_metrics.png                               │  │
│  │    ├─ Rolling Sharpe                                 │  │
│  │    ├─ Rolling volatility                             │  │
│  │    └─ Cumulative returns                             │  │
│  │                                                       │  │
│  │ 5. returns_distribution.png                          │  │
│  │    ├─ Histogram + normal curve                       │  │
│  │    ├─ Q-Q plot                                       │  │
│  │    └─ Statistics table                               │  │
│  └───────────────────────┬──────────────────────────────┘  │
│                          │                                   │
│                          ▼                                   │
│  REPORTS                                                    │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ • backtest_report.html (interactive)                 │  │
│  │ • trade_log.csv (all trades)                         │  │
│  │ • parameter_sweep.csv (optimization results)         │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

## 🔄 Execution Flow (Daily Loop)

```
START OF DAY
     │
     ▼
┌─────────────────────────┐
│ 1. Check Exit Signals   │
│    (existing positions) │
└────────┬────────────────┘
         │
         ▼
┌─────────────────────────┐
│ 2. Execute Exits        │
│    • Update cash        │
│    • Record trade       │
└────────┬────────────────┘
         │
         ▼
┌─────────────────────────┐
│ 3. Screen for Entries   │
│    • Dividend calendar  │
│    • Quality filters    │
└────────┬────────────────┘
         │
         ▼
┌─────────────────────────┐
│ 4. Generate Signals     │
│    • Technical analysis │
│    • Mean reversion     │
└────────┬────────────────┘
         │
         ▼
┌─────────────────────────┐
│ 5. Position Sizing      │
│    • Kelly criterion    │
│    • Risk limits        │
└────────┬────────────────┘
         │
         ▼
┌─────────────────────────┐
│ 6. Execute Entries      │
│    • Apply costs        │
│    • Update cash        │
│    • Record trade       │
└────────┬────────────────┘
         │
         ▼
┌─────────────────────────┐
│ 7. Update Portfolio     │
│    • Calculate value    │
│    • Update metrics     │
│    • Record equity      │
└────────┬────────────────┘
         │
         ▼
┌─────────────────────────┐
│ 8. Check Risk Limits    │
│    • Circuit breakers   │
│    • Stop trading if hit│
└────────┬────────────────┘
         │
         ▼
  END OF DAY
```

## 📁 File Responsibilities

```
config.py (413 lines)
├─ All tunable parameters
├─ Data configurations
├─ Strategy rules
├─ Risk limits
└─ Validation functions

data_manager.py (633 lines)
├─ Alpaca API integration
├─ yfinance integration
├─ Dividend calendar
├─ Technical indicators
├─ Quality scoring
└─ Mean reversion estimation

strategy.py (490 lines)
├─ Entry signal generation
├─ Exit signal detection
├─ Position tracking
├─ Trade statistics
└─ Portfolio summary

risk_manager.py (458 lines)
├─ Position sizing (Kelly)
├─ Portfolio constraints
├─ Circuit breakers
├─ Risk metrics (VaR, CVaR)
├─ Correlation monitoring
└─ Sector limits

backtester.py (655 lines)
├─ Simulation engine
├─ Transaction costs
├─ Walk-forward analysis
├─ Performance calculation
└─ Trade execution

analytics.py (592 lines)
├─ All visualizations
├─ Performance metrics
├─ HTML report generation
└─ Statistical analysis

main.py (256 lines)
├─ User interface
├─ Orchestration
├─ Mode selection
└─ Parameter sweep

setup.py (206 lines)
├─ Dependency checking
├─ API key configuration
├─ Quick validation
└─ Setup wizard
```

## 🎯 Data Flow Example

```
User runs: python main.py

1. main.py
   ├─ Validates config
   ├─ User selects mode
   └─ Calls backtester.py

2. backtester.py
   ├─ Initializes components
   │  ├─ data_manager
   │  ├─ strategy
   │  └─ risk_manager
   │
   ├─ Fetches dividend calendar (data_manager)
   │
   └─ FOR EACH TRADING DAY:
      │
      ├─ strategy.check_exit_signals()
      │  └─ Returns list of exits
      │
      ├─ Execute exits
      │  └─ Update cash, record trades
      │
      ├─ data_manager.screen_stocks()
      │  └─ Returns qualified stocks
      │
      ├─ strategy.generate_entry_signals()
      │  └─ Returns ranked signals
      │
      ├─ risk_manager.get_position_allocation()
      │  └─ Returns sized positions
      │
      ├─ Execute entries
      │  └─ Update cash, record trades
      │
      ├─ Calculate portfolio value
      │  └─ Record in equity curve
      │
      └─ Check circuit breakers
         └─ Stop if limits hit

3. Calculate final metrics
   └─ Returns performance dict

4. analytics.py
   ├─ Generate all plots
   ├─ Create HTML report
   └─ Export trade log

5. Output files created:
   ├─ /mnt/user-data/outputs/backtest_report.html
   ├─ /mnt/user-data/outputs/equity_curve.png
   ├─ /mnt/user-data/outputs/drawdown.png
   ├─ /mnt/user-data/outputs/monthly_returns.png
   ├─ /mnt/user-data/outputs/rolling_metrics.png
   ├─ /mnt/user-data/outputs/returns_distribution.png
   └─ /mnt/user-data/outputs/trade_log.csv
```

## 🔌 API Integration Points

```
┌──────────────┐
│ Alpaca API   │
├──────────────┤
│ Endpoints:   │
│ • get_bars   │ → Price data (OHLCV)
│ • get_account│ → Account status
│ • list_assets│ → Available tickers
└──────────────┘

┌──────────────┐
│ yfinance     │
├──────────────┤
│ Methods:     │
│ • Ticker()   │ → Stock object
│ • .dividends │ → Dividend history
│ • .actions   │ → Corporate actions
│ • .info      │ → Fundamentals
│ • .history() │ → Price history
└──────────────┘
```

---

This architecture provides:
✅ **Modularity** - Each component is independent
✅ **Testability** - Each module can be tested separately
✅ **Maintainability** - Clear separation of concerns
✅ **Scalability** - Easy to add new features
✅ **Reliability** - Multiple layers of validation
